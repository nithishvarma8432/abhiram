# Contributors

Here you have the awesome people who contributed to this list (ordered **alphabetically** by **surname**):

- [Andy Alt](https://github.com/andy5995/).
- [Joe Bell](https://github.com/joe-bell).
- [Agustín Covarrubias](https://github.com/agucova).
- [Matjaž Drolc](https://github.com/drola).
- [Nazeefa Fatima](https://github.com/Nazeeefa).
- [Isaac Friedman](https://github.com/isaac-friedman)
- [Iván González](https://github.com/dreamingechoes).
- [Gavin Henderson](https://github.com/gavinhenderson).
- [Diego Maximiliano](https://github.com/diemax).
- [Desi Rottman](https://github.com/desirottman).
- [Sigute](https://github.com/sigute).
- [Spencer Smith](https://github.com/dotspencer).
- [Alice Zhao](https://github.com/alicelovescake).
- [Zack Zlotnik](https://github.com/cheesesashimi).
